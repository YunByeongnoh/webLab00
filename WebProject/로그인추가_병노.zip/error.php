<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Simple Timeline</title>
        <link rel="stylesheet" href="timeline.css">
    </head>
    <body>
        <div>
            <h1>Simple - ERROR</h1>
            <p>
                <a href="MKID.php">Try Again?</a>
            </p>
        </div>
    </body>
</html>
